from flask import Flask, render_template, request
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import os

app=Flask(__name__)



df22 = pd.read_csv('df22.csv')
df22 = df22.set_index('Champion')
df1 = pd.read_csv('df1.csv')
df23 = pd.read_csv('df23.csv')

l1 = list(df1['tags'])

l2 = []

for element in l1:
    #print (type(element))
    element = element.replace("'", '')
    l2.append(element)

l3 = []
for element in l2:
    #print (type(element))
    res = element.strip('][').split(', ') 
    l3.append(res)

df1['tags'] = l3

import random
#val = input("Enter your feature: ['Fighter', 'Tank', 'Mage', 'Assassin', 'Support', 'Marksman'] ")  
def first_cham(tag):
    list1 = []
    count = 0
    for i in list(df1.tags):
        if tag in i:
            list1.append(count)
        count += 1  
    return(df1.loc[random.choice(list1), 'Champion'])

from scipy.spatial.distance import euclidean
from scipy.spatial.distance import hamming
# lets write a function to compute k nearest neighbours of active user


def comparisonFunc(chamname,champion_df,champion):
    index_list = []
    #print(list(champion_df['tags'][champion_df.Champion==champion])[0])
    chamname = chamname.set_index(pd.Index(range(len(chamname))))
    
    #print(chamname)
    for i,e in enumerate(chamname['tags']):
        #print(i,e)
        #print(e)
        for a in e:
            if a in list(champion_df['tags'][champion_df.Champion==champion])[0]:
                index_list.append(chamname.Champion[i])

    return list(set(index_list))


# To Find the k nearest neighbours of movies, first find the distance of input movie to all other movies.
def nearestneighbours(Champion, K, difficulty, lane):
    # create a user df that contains all users except active user
    
    allChamName = pd.DataFrame(df22.index)
    #print(allChamName)    
    allChamName["tags"] = df1.tags
    allChamName["difficulty"] = df1.difficulty
    allChamName['Top'] = df23.Top
    allChamName['Jungle'] = df23.Jungle
    allChamName['Middle'] = df23.Middle
    allChamName['Bottom'] = df23.Bottom
    allChamName['Support'] = df23.Support
    allChamName = allChamName[allChamName.Champion!=Champion]
    # Add a column to this df which contains distance of active movie to each movie
    allChamName["distance"] = allChamName["Champion"].apply(lambda x: hamming(df22.loc[Champion],df22.loc[x]))


    print('This is allChamName')
    print(allChamName)
    print(allChamName[0:24])
    if lane == 'Top':
        allChamName = allChamName[allChamName.Top == 1]
    if lane == 'Jungle':
        allChamName = allChamName[allChamName.Jungle == 1]
    if lane == 'Middle':
        allChamName = allChamName[allChamName.Middle == 1]
    if lane == 'Bottom':
        allChamName = allChamName[allChamName.Bottom == 1]
    if lane == 'Support':
        allChamName = allChamName[allChamName.Support == 1]
    print('This is after lane allChamName')
    print(allChamName)

    #print(allChamName)
    #allChamName = allChamName[allChamName["tags"] in allChamName[allChamName["Champion"] == Champion]]
    # if difficulty is not none...
    if difficulty != 'None':
        allChamName = allChamName[allChamName.difficulty == difficulty]
    #print(allChamName)
    #print(list(df11['tags'][df11.Champion==Champion])[0])
    #print(allChamName)
    #print(comparisonFunc(allChamName,df11,Champion))
    allChamName = allChamName[allChamName['Champion'].isin(comparisonFunc(allChamName,df1,Champion))]
    #allChamName = allChamName[allChamName['Champion'] in comparisonFunc(allChamName,df11,Champion)]
    print(allChamName)
    KnearestUsers = allChamName.sort_values(["distance"],ascending=True)["Champion"][:K]
    print(KnearestUsers)
    KnearestUsersDistance = allChamName.sort_values(["distance"],ascending=True)["distance"][:K]
    #KnearestUsers = KnearestUsers[KnearestUser]
    
    # for cn in list(KnearestUsers):
    #     img=mpimg.imread(str(cn) +'.png')
    #     imgplot = plt.imshow(img)
    #     plt.show()
    return KnearestUsers #,KnearestUsersDistance


@app.route('/')
def home():
    return render_template("home.html")

def ValuePredictor(to_predict_list):
    to_predict = np.array(to_predict_list).reshape(1, -1)   
    result = loaded_model.predict(loaded_model2.transform(to_predict))
    return result[0]

@app.route('/fresult',methods = ['POST'])

def fresult():
    #fprediction=''
    if request.method == 'POST':
        ftag = request.form.to_dict()['flevel']
        fcham = first_cham(ftag)

        PEOPLE_FOLDER = os.path.join('static', 'champion_images')
        full_filename = os.path.join(PEOPLE_FOLDER, str(fcham)+'.png')

        return render_template("result0.html", fcham= fcham, image0 = full_filename) 

@app.route('/result',methods = ['POST'])


def result():
    prediction=''
    if request.method == 'POST':
        champion =request.form.to_dict()['slevel1']
        number = int(request.form.to_dict()['slevel2'])
        difficulty = request.form.to_dict()['slevel3']
        lane = request.form.to_dict()['slevel4']
        print('This is the lane')
        print(lane)
        
        result = nearestneighbours(champion,number,difficulty,lane)

        
        print("result from model", result)
        prediction = result
        print(prediction)
        print(list(prediction))
        PEOPLE_FOLDER = os.path.join('static', 'champion_images')
        #full_filename1 = os.path.join(PEOPLE_FOLDER, 'Aatrox.png')

        filename_list = []
        for i in list(prediction):
            print(PEOPLE_FOLDER)
            full_filename = os.path.join(PEOPLE_FOLDER, str(i)+'.png')
            print(full_filename)
            filename_list.append(full_filename)
        return render_template("result.html",prediction= list(prediction),images=filename_list )

if __name__ == "__main__":
    app.run()